/*
 * Pepsi_16X2_ultra.h
 *
 */


#include "Pepsi_16X2_ultra.h"						/* Include LCD header file */


void LCD_Command (char a)							/* LCD command write function */
{
int un,ln;			// defining upper nibble and lower nible
un=a & 0xf0;		//passing upper nibble to the lcd
_delay_ms(10);
PORTD=un|0x04;		
_delay_ms(10);
PORTD=un|0x00;
_delay_ms(10);

ln=(a<<4) & 0xf0;	//passing lower nibble to the lcd
_delay_ms(10);
PORTD=ln|0x04;
_delay_ms(10);
PORTD=ln|0x00;
_delay_ms(10);
	
}

void LCD_Char (char a)						/* LCD data write function */
{
	char un,ln;
un=a & 0xf0;
_delay_ms(10);
PORTD=un|0x05;
_delay_ms(10);
PORTD=un|0x01;
_delay_ms(10);


ln=(a<<4) & 0xf0;
_delay_ms(10);
PORTD=ln|0x05;
_delay_ms(10);
PORTD=ln|0x01;
_delay_ms(10);
}

void LCD_Init (void)								/* LCD Initialize function */
{
	lcd_cmd(0x02);
lcd_cmd(0x28);
lcd_cmd(0x01);
lcd_cmd(0x06);
lcd_cmd(0x0f);
}

void LCD_String (char *str)							/* Send string to LCD function */
{
	int i;
	for(i=0;str[i]!=0;i++)							/* Send each char of string till the NULL */
	{
		LCD_Char (str[i]);							/* Call LCD data write */
	}
}

void LCD_String_xy (char row, char pos, char *str)	/* Send string to LCD function */
{
	if (row == 1)
		LCD_Command((pos & 0x0F)|0x80);				/* Command of first row and required position<16 */
	else if (row == 2)
		LCD_Command((pos & 0x0F)|0xC0);				/* Command of Second row and required position<16 */
	LCD_String(str);								/* Call LCD string function */
}

void LCD_Clear (void)								/* LCD clear function */
{
	LCD_Command (0x01);								/* Clear LCD command */
	_delay_ms(2);
	LCD_Command (0x80);								/* 8 is for first line and 0 is for 0th position */
}
