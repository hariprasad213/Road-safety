/*
 * Ultrasonic sensor HC-05 interfacing with ATmega16
 * http://www.electronicwings.com
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <stdlib.h>
#include "Pepsi_16X2_ultra.h"/* Include LCD header file */

//#define  Trigger_pin	PA0	/* Trigger pin */

int TimerOverflow = 0;

ISR(TIMER1_OVF_vect)
{
	TimerOverflow++;		/* Increment Timer Overflow count */
}
void func1 (Trigger_pin,PD)
{
		PORTA |= (1 << Trigger_pin);/* Give 10us trigger pulse on trig. pin to HC-SR04 */
		_delay_us(10);
		PORTA &= (~(1 << Trigger_pin));
		
		TCNT1 = 0;			/* Clear Timer counter */
		TCCR1B = 0x41;		/* Setting for capture rising edge, No pre-scaler*/
		TIFR = 1<<PD;		/* Clear ICP flag (Input Capture flag) */
		TIFR = 1<<TOV1;		/* Clear Timer Overflow flag */

		/*Calculate width of Echo by Input Capture (ICP) on PortD PD6 */
		
		while ((TIFR & (1 << PD)) == 0);	/* Wait for rising edge */
		TCNT1 = 0;			/* Clear Timer counter */
		TCCR1B = 0x01;		/* Setting for capture falling edge, No pre-scaler */
		TIFR = 1<<PD;		/* Clear ICP flag (Input Capture flag) */
		TIFR = 1<<TOV1;		/* Clear Timer Overflow flag */
		TimerOverflow = 0;	/* Clear Timer overflow count */

		while ((TIFR & (1 << PD)) == 0); /* Wait for falling edge */
		count = ICR1 + (65535 * TimerOverflow);	/* Take value of capture register */
		/* 8MHz Timer freq, sound speed =343 m/s, calculation mentioned in doc. */
		distance = (double)count / 466.47;

		dtostrf(distance, 2, 2, string);/* Convert distance into string */
		strcat(string, " cm   ");
		LCD_String_xy(2, 0, "Dist = ");
		LCD_String_xy(2, 7, string);	/* Print distance on LDC16x2 */
		_delay_ms(200);
	
}

int main(void)
{
	char string[10];
	long count;
	double distance;
	DDRC=0XFF;
	DDRA = 0xFF;			/* Make trigger pin as output */
	PORTD = 0xFF;			/* Turn on Pull-up */
	
	LCD_Init();
	LCD_String_xy(1, 0, "Ultrasonic");
	
	sei();					/* Enable global interrupt */
	TIMSK = (1 << TOIE1);	/* Enable Timer1 overflow interrupts */
	TCCR1A = 0;				/* Set all bit to zero Normal operation */
	
	while(1)
	{
	func1 (PA0,PD0);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0X03;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}
	
	func1 (PA1,PD1);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0X07;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}
	
	func1 (PA2,PD2);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0X0E;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}
	
	func1 (PA3,PD3);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0X1C;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}
	
	func1 (PA4,PD4);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0X38;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}
	func1 (PA5,PD5);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0X70;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}
	
	func1 (PA6,PD6);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0XE0;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}
	
	func1 (PA7,PD7);
	_delay_ms(200);
	if (distance<=30)
	{
		PORTC=0XC0;
		_delay_ms(200);
	}
	else
	{
		PORTC=0X00;
		_delay_ms(200);
	}

	}
}
