import numpy as np
import cv2
img_counter=0
face_cascade=cv2.CascadeClassifier('E:\haarcascade_frontalface_default.xml')#predefined cascade
eye_cascade=cv2.CascadeClassifier('E:\haarcascade_eye.xml')#predefined cascade
cap=cv2.VideoCapture(1)
while True:
    ret,frame=cap.read()#captures video
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray,1.3,5)
    for (x,y,w,h) in faces:
        cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)#for creating a rectangle around a face
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = frame[y:y+h, x:x+w]
        eyes = eye_cascade.detectMultiScale(roi_gray)
        #for (ex,ey,ew,eh) in eyes:
         #   cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2) #for creating rectangle around eyes
    cv2.imshow('frame',frame)#display video 
    k=cv2.waitKey(30) & 0xFF
    if k==27:#ESC pressed
        break
    elif k==32:#SPACE pressed
        img_name="opencv_frame_{}.png".format(img_counter)
        cv2.imwrite(img_name,frame)#takes snap 
        print("{} written!".format(img_name))
        img_counter+=1
cap.release()
cv2.destroyAllWindows()
